//
//  ViewController.swift
//  UiButtonChallenge
//
//  Created by Brennan Duff on 9/8/20.
//  Copyright © 2020 Brennan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

    }

    @IBAction func myButton(_ sender: UIButton) {
        view.backgroundColor = UIColor.green
        myLabel.text = "It's not easy being green."
    }
    
    @IBAction func resetButton(_ sender: UIButton) {view.backgroundColor = UIColor.darkGray
        myLabel.text = "What color am I?"
    }
}

